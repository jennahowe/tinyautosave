﻿tinyMCE.addI18n('da.tinyautosave',{
restore_content: "Gendan sikkerhedskopi",
no_content: "Der er ingen sikkerhedskopi tilgængelig",
warning_message: "Hvis du gendanner sikkerhedskopien, vil du miste alt det indhold, der i øjeblikket er i editoren.\n\nEr du sikker på at du vil gendanne sikkerhedskopien?"
});